﻿using Photon.Deterministic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Quantum.Core {
  [Obsolete("PhysicsSystemPost is not used anymore, remove this reference from SystemSetup.cs")]
  public unsafe class PhysicsSystemPost : SystemBase {
    public override void Update(Frame f) {

    }
  }
}
